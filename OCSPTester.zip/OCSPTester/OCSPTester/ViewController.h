//
//  ViewController.h
//  OCSPTester
//
//  Created by H. M. Shahriar on 7/5/17.
//  Copyright © 2017 SELF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

