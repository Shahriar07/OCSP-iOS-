//
//  ViewController.m
//  OCSPTester
//
//  Created by H. M. Shahriar on 7/5/17.
//  Copyright © 2017 SELF. All rights reserved.
//

#import "CertificateValidationServiceOCSP.h"
#import <openssl/ocsp.h>
#import <openssl/ssl.h>
#import <openssl/x509.h>

@implementation CertificateValidationServiceOCSP

-(int)verifyCertificate:(NSData*)cert issuingCert:(NSData*)issuingCert host:(char *) host path:(char *)path port:(char *)port{

    STACK_OF(X509) *issuers = NULL;
    const EVP_MD *cert_id_md = NULL;
    ASN1_INTEGER *serial;
    OCSP_RESPONSE *response;
    STACK_OF(OPENSSL_STRING) *reqnames = sk_OPENSSL_STRING_new_null();
    if (reqnames == NULL){
        //TODO Need to throw exception
        return 1;
    }


    STACK_OF(OCSP_CERTID) *ids = sk_OCSP_CERTID_new_null();

    const unsigned char *crtBytes = (const unsigned char*)[cert bytes];
    X509 *certificateX509 = d2i_X509(NULL, &crtBytes, [cert length]);
    serial = X509_get_serialNumber(certificateX509);

    const unsigned char *issuingCrtBytes = (const unsigned char*)[issuingCert bytes];
    X509 *issuerCrt = d2i_X509(NULL, &issuingCrtBytes, [issuingCert length]);

    if (certificateX509 != nil && issuerCrt  != nil) {
        OCSP_REQUEST *req = OCSP_REQUEST_new();
        if (issuers == NULL) {
            if ((issuers = sk_X509_new_null()) != NULL){
               sk_X509_push(issuers, issuerCrt);
            }
            else{
                //TODO Need to throw exception
                return 1;
            }
        }


//        if (cert_id_md == NULL)
//            cert_id_md = EVP_sha1();
//        if (![self add_ocsp_cert:&req cert:certificateX509 cert_id_md:cert_id_md issuer:issuerCrt ids:ids]){
//            //TODO Need to throw exception
//            return 1;
//        }


        if (cert_id_md == NULL)
            cert_id_md = EVP_sha1();
        if (![self add_ocsp_serial:&req serial:serial cert_id_md:cert_id_md issuer:issuerCrt ids:ids])
        {
            //TODO Need to throw exception
            return 2;
        }

//        response = [self process_responder:req host:"10.88.231.230" path:"/" port:"4040" use_ssl:0 headers:NULL req_timeout:60];
        response = [self process_responder:req host:host path:path port:port use_ssl:0 headers:NULL req_timeout:60];
        ASN1_INTEGER_free(serial);
        if (response == NULL) {
            NSLog(@"Responder Error");
            return 2;
        }
        int i = OCSP_response_status(response);
        if (i != OCSP_RESPONSE_STATUS_SUCCESSFUL) {
            NSLog(@"Responder Error: %s (%d)\n",
                       OCSP_response_status_str(i), i);
            return i;
        }
        else{
            NSLog(@"Response status success");
            return 0;
//# define OCSP_RESPONSE_STATUS_MALFORMEDREQUEST     1
//# define OCSP_RESPONSE_STATUS_INTERNALERROR        2
//# define OCSP_RESPONSE_STATUS_TRYLATER             3
//# define OCSP_RESPONSE_STATUS_SIGREQUIRED          5
//# define OCSP_RESPONSE_STATUS_UNAUTHORIZED         6
        }
    }
    else{
        return 1;
    }
}

-(int) add_ocsp_cert:(OCSP_REQUEST**) req  cert:(X509 *)cert
          cert_id_md:(const EVP_MD *)cert_id_md issuer:(X509 *)issuer
                 ids:(STACK_OF(OCSP_CERTID) *)ids
{
    OCSP_CERTID *certId;

    if (issuer == NULL) {
        NSLog(@"No issuer certificate specified\n");
        return 0;
    }
    if (*req == NULL)
        *req = OCSP_REQUEST_new();
    if (*req == NULL)
        goto err;
    certId = OCSP_cert_to_id(cert_id_md, cert, issuer);
    if (certId == NULL || !sk_OCSP_CERTID_push(ids, certId))
        goto err;
    if (!OCSP_request_add0_id(*req, certId))
        goto err;
    return 1;

err:
    NSLog(@"Error Creating OCSP request\n");
    return 0;
}

-(int) add_ocsp_serial:(OCSP_REQUEST **)req serial:(ASN1_INTEGER *)serial
            cert_id_md:(const EVP_MD *)cert_id_md issuer:(X509 *)issuer
                           ids:(STACK_OF(OCSP_CERTID) *)ids
{
    OCSP_CERTID *certId;
    X509_NAME *iname;
    ASN1_BIT_STRING *ikey;

    if (issuer == NULL) {
        NSLog(@"No issuer certificate specified\n");
        return 0;
    }
    if (*req == NULL)
        *req = OCSP_REQUEST_new();
    if (*req == NULL)
        goto err;
    iname = X509_get_subject_name(issuer);
    ikey = X509_get0_pubkey_bitstr(issuer);

    certId = OCSP_cert_id_new(cert_id_md, iname, ikey, serial);
    if (certId == NULL || !sk_OCSP_CERTID_push(ids, certId))
        goto err;
    if (!OCSP_request_add0_id(*req, certId))
        goto err;
    return 1;

err:
    NSLog(@"Error Creating OCSP request\n");
    return 0;
}


-(OCSP_RESPONSE*) process_responder:(OCSP_REQUEST *)req
                               host:(const char *) host path:(const char *) path
                               port:(const char *) port use_ssl:(int) use_ssl
                            headers:(STACK_OF(CONF_VALUE) *) headers
                        req_timeout:(int) req_timeout
{
    BIO *cbio = NULL;
    SSL_CTX *ctx = NULL;
    OCSP_RESPONSE *resp = NULL;

    cbio = BIO_new_connect(host);
    if (cbio == NULL) {
        NSLog(@"Error creating connect BIO\n");
        goto end;
    }
    if (port != NULL)
        BIO_set_conn_port(cbio, port);
    if (use_ssl == 1) {
        BIO *sbio;
        ctx = SSL_CTX_new(DTLS_client_method());
        if (ctx == NULL) {
            NSLog(@"Error creating SSL context.\n");
            goto end;
        }
        SSL_CTX_set_mode(ctx, SSL_MODE_AUTO_RETRY);
        sbio = BIO_new_ssl(ctx, 1);
        cbio = BIO_push(sbio, cbio);
    }

    resp = [self query_responder:cbio host:host path:path headers:headers req:req req_timeout:req_timeout];
    if (resp == NULL)
        NSLog(@"Error querying OCSP responder\n");
end:
    BIO_free_all(cbio);
    SSL_CTX_free(ctx);
    return resp;
}


-(OCSP_RESPONSE *) query_responder:(BIO *)cbio host:(const char *)host
                              path:(const char *)path
                           headers:(const STACK_OF(CONF_VALUE) *)headers
                               req:(OCSP_REQUEST *)req
                       req_timeout:(int) req_timeout
{
    int fd;
    int rv;
    int i;
    int add_host = 1;
    OCSP_REQ_CTX *ctx = NULL;
    OCSP_RESPONSE *rsp = NULL;
    fd_set confds;
    struct timeval tv;

    if (req_timeout != -1)
        BIO_set_nbio(cbio, 1);

    rv = BIO_do_connect(cbio);

    if ((rv <= 0) && ((req_timeout == -1) || !BIO_should_retry(cbio))) {
//        BIO_puts(bio_err, "Error connecting BIO\n");
        return NULL;
    }

    if (BIO_get_fd(cbio, &fd) < 0) {
//        BIO_puts(bio_err, "Can't get connection fd\n");
        goto err;
    }

    if (req_timeout != -1 && rv <= 0) {
        FD_ZERO(&confds);
        openssl_fdset(fd, &confds);
        tv.tv_usec = 0;
        tv.tv_sec = req_timeout;
        rv = select(fd + 1, NULL, (void *)&confds, NULL, &tv);
        if (rv == 0) {
//            BIO_puts(bio_err, "Timeout on connect\n");
            return NULL;
        }
    }

    ctx = OCSP_sendreq_new(cbio, path, NULL, -1);
    if (ctx == NULL)
        return NULL;

    for (i = 0; i < sk_CONF_VALUE_num(headers); i++) {
        CONF_VALUE *hdr = sk_CONF_VALUE_value(headers, i);
        if (add_host == 1 && strcasecmp("host", hdr->name) == 0)
            add_host = 0;
        if (!OCSP_REQ_CTX_add1_header(ctx, hdr->name, hdr->value))
            goto err;
    }

    if (add_host == 1 && OCSP_REQ_CTX_add1_header(ctx, "Host", host) == 0)
        goto err;

    if (!OCSP_REQ_CTX_set1_req(ctx, req))
        goto err;

    for (;;) {
        rv = OCSP_sendreq_nbio(&rsp, ctx);
        if (rv != -1)
            break;
        if (req_timeout == -1)
            continue;
        FD_ZERO(&confds);
        openssl_fdset(fd, &confds);
        tv.tv_usec = 0;
        tv.tv_sec = req_timeout;
        if (BIO_should_read(cbio)) {
            rv = select(fd + 1, (void *)&confds, NULL, NULL, &tv);
        } else if (BIO_should_write(cbio)) {
            rv = select(fd + 1, NULL, (void *)&confds, NULL, &tv);
        } else {
//            BIO_puts(bio_err, "Unexpected retry condition\n");
            goto err;
        }
        if (rv == 0) {
//            BIO_puts(bio_err, "Timeout on request\n");
            break;
        }
        if (rv == -1) {
//            BIO_puts(bio_err, "Select error\n");
            break;
        }

    }
err:
    OCSP_REQ_CTX_free(ctx);
    
    return rsp;
}


@end
