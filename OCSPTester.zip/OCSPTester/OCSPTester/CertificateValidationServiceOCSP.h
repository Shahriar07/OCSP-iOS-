//
//  ViewController.m
//  OCSPTester
//
//  Created by H. M. Shahriar on 7/5/17.
//  Copyright © 2017 SELF. All rights reserved.
//

#import <Foundation/Foundation.h>

# if defined(OPENSSL_SYS_WIN32) || defined(OPENSSL_SYS_WINCE)
#  define openssl_fdset(a,b) FD_SET((unsigned int)a, b)
# else
#  define openssl_fdset(a,b) FD_SET(a, b)
# endif

@interface CertificateValidationServiceOCSP : NSObject

-(int)verifyCertificate:(NSData*)cert issuingCert:(NSData*)issuingCert host:(char *) host path:(char *)path port:(char *)port;

@end
